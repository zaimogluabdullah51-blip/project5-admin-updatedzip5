const caseSelect = document.getElementById("case-select");
const tckFilter = document.getElementById("tck-filter");
const nameSearch = document.getElementById("name-search");
const mapClose = document.getElementById("map-close");
const mapTitle = document.getElementById("map-title");

const caseTitle = document.getElementById("case-title");
const caseNumber = document.getElementById("case-number");
const caseCourt = document.getElementById("case-court");
const caseJudge = document.getElementById("case-judge");
const casePanel = document.getElementById("case-panel");
const caseProsecutor = document.getElementById("case-prosecutor");
const caseHearings = document.getElementById("case-hearings");
const caseDefendants = document.getElementById("case-defendants");
const caseDates = document.getElementById("case-dates");
const caseDetailBtn = document.getElementById("case-detail");

const caseModal = document.getElementById("case-modal");
const caseClose = document.getElementById("case-close");
const caseDetailTitle = document.getElementById("case-detail-title");
const caseDetailNumber = document.getElementById("case-detail-number");
const caseDetailCourt = document.getElementById("case-detail-court");
const caseDetailJudge = document.getElementById("case-detail-judge");
const caseDetailPanel = document.getElementById("case-detail-panel");
const caseDetailProsecutor = document.getElementById("case-detail-prosecutor");
const caseDetailHearings = document.getElementById("case-detail-hearings");
const caseDetailStart = document.getElementById("case-detail-start");
const caseDetailLast = document.getElementById("case-detail-last");
const caseDetailSummary = document.getElementById("case-detail-summary");

const personModal = document.getElementById("person-modal");
const personClose = document.getElementById("person-close");
const personName = document.getElementById("person-name");
const personRole = document.getElementById("person-role");
const personPhoto = document.getElementById("person-photo");
const personAccusationsTag = document.getElementById("person-accusations");
const personAccusationList = document.getElementById("person-accusation-list");
const personEvidenceList = document.getElementById("person-evidence-list");
const personDefenseList = document.getElementById("person-defense-list");
const personRelatedList = document.getElementById("person-related-list");

let network = null;
let cases = [];
let people = [];
let nodesCache = [];
let edgesCache = [];

const fallbackImage = "/assets/default-avatar.svg";

const roleColors = {
  defendant: "#6B7280",
  informant: "#D4AF37",
  witness: "#3B82F6",
  secretWitness: "#E5E7EB",
  victim: "#8B5CF6",
  fugitive: "#DC2626",
  detained: "#F97316"
};

function normalizeRole(role) {
  const value = (role || "").toLowerCase();
  if (value.includes("itiraf")) return "informant";
  if (value.includes("gizli")) return "secretWitness";
  if (value.includes("tanık")) return "witness";
  if (value.includes("mağdur") || value.includes("müşteki")) return "victim";
  if (value.includes("firari")) return "fugitive";
  if (value.includes("tutuk")) return "detained";
  return "defendant";
}

async function fetchJSON(url, options) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed");
  return data;
}

function setCaseOptions() {
  caseSelect.innerHTML = "";
  cases.forEach((item) => {
    const option = document.createElement("option");
    option.value = item.id;
    option.textContent = item.title;
    caseSelect.appendChild(option);
  });
}

function setTckOptions(tckArticles) {
  tckFilter.innerHTML = `<option value="all">Tüm TCK Maddeleri</option>`;
  tckArticles.forEach((article) => {
    const option = document.createElement("option");
    option.value = article.code;
    option.textContent = `TCK ${article.code} - ${article.title || ""}`;
    tckFilter.appendChild(option);
  });
}

function renderCaseInfo(caseData) {
  mapTitle.textContent = caseData.title || "Dava Analiz Haritası";
  caseTitle.textContent = caseData.title || "—";
  caseNumber.textContent = caseData.case_number || "—";
  caseCourt.textContent = caseData.court_name || "—";
  caseJudge.textContent = caseData.judge || "—";
  casePanel.textContent = caseData.court_panel || "—";
  caseProsecutor.textContent = caseData.prosecutor || "—";
  caseHearings.textContent = caseData.hearing_count || "—";
  const defendantCount = (caseData.people || []).filter((p) => !p.is_external).length;
  caseDefendants.textContent = defendantCount || "—";
  const dates = [caseData.start_date, caseData.last_hearing_date].filter(Boolean).join(" • ");
  caseDates.textContent = dates || "—";

  caseDetailTitle.textContent = caseData.title || "—";
  caseDetailNumber.textContent = caseData.case_number || "—";
  caseDetailCourt.textContent = caseData.court_name || "—";
  caseDetailJudge.textContent = caseData.judge || "—";
  caseDetailPanel.textContent = caseData.court_panel || "—";
  caseDetailProsecutor.textContent = caseData.prosecutor || "—";
  caseDetailHearings.textContent = caseData.hearing_count || "—";
  caseDetailStart.textContent = caseData.start_date || "—";
  caseDetailLast.textContent = caseData.last_hearing_date || "—";
  caseDetailSummary.textContent = caseData.summary || "—";
}

function buildPlaceholderActions(caseData) {
  const profiles = caseData.people || [];
  const ids = profiles.map((p) => p.id);
  const tck = caseData.tck_articles || [];
  const tck314 = tck.find((t) => t.code === "314/2") || { code: "314/2", title: "Silahlı Örgüt Üyeliği" };
  const tck299 = tck.find((t) => t.code === "299") || { code: "299", title: "Cumhurbaşkanına Hakaret" };
  const tck220 = tck.find((t) => t.code === "220/7") || { code: "220/7", title: "Örgüte Yardım" };

  return [
    {
      id: "action-1",
      title: "Örgüt Toplantısı",
      date: "2024-03-15",
      tckCodes: [tck314.code, tck299.code],
      profileMap: {
        [tck314.code]: ids.slice(0, 3),
        [tck299.code]: ids.slice(1, 3)
      }
    },
    {
      id: "action-2",
      title: "Para Transferi",
      date: "2024-04-22",
      tckCodes: [tck220.code],
      profileMap: {
        [tck220.code]: ids.slice(0, 2)
      }
    }
  ];
}

function buildGraph(caseData, localMeta) {
  const actions = localMeta?._actions?.length
    ? localMeta._actions
    : buildPlaceholderActions(caseData);

  const tckMap = new Map((caseData.tck_articles || []).map((t) => [t.code, t]));
  const actionGap = 260;
  const tckGap = 160;
  const nodeGapX = 120;
  const nodeGapY = 90;

  const nodes = [];
  const edges = [];
  const personById = new Map(caseData.people.map((p) => [p.id, p]));
  const nodeIdByProfile = new Map();

  actions.forEach((action, actionIndex) => {
    const actionY = actionIndex * actionGap;
    nodes.push({
      id: `action:${action.id}`,
      label: `${action.title}${action.date ? ` (${action.date})` : ""}`,
      shape: "box",
      x: 0,
      y: actionY,
      fixed: { x: true, y: true },
      color: { background: "#111827", border: "rgba(255,255,255,0.12)" },
      font: { color: "#e5e7eb", size: 13, face: "Libre Baskerville" },
      widthConstraint: { minimum: 680 },
      heightConstraint: { minimum: 48 },
      selectable: false
    });

    const tckCodes = action.tckCodes || Object.keys(action.profileMap || {});
    tckCodes.forEach((code, groupIndex) => {
      const tckMeta = tckMap.get(code) || { title: "" };
      const groupY = actionY + 80 + groupIndex * tckGap;
      nodes.push({
        id: `tck:${action.id}:${code}`,
        label: `TCK ${code} - ${tckMeta.title || ""}`,
        shape: "box",
        x: 0,
        y: groupY,
        fixed: { x: true, y: true },
        color: { background: "rgba(17,24,39,0.7)", border: "rgba(255,255,255,0.08)" },
        font: { color: "#e5e7eb", size: 12, face: "Inter" },
        widthConstraint: { minimum: 520 },
        heightConstraint: { minimum: 32 },
        selectable: false
      });

      const profileIds = (action.profileMap && action.profileMap[code]) ||
        caseData.people.filter((p) => (p.tck_articles || []).includes(code)).map((p) => p.id);

      profileIds.forEach((profileId, idx) => {
        const person = personById.get(profileId);
        if (!person) return;
        const roleKey = normalizeRole(person.role);
        const borderColor = roleColors[roleKey] || roleColors.defendant;
        const x = -260 + (idx % 4) * nodeGapX;
        const y = groupY + 80 + Math.floor(idx / 4) * nodeGapY;
        const nodeId = `p:${action.id}:${code}:${profileId}`;

        nodes.push({
          id: nodeId,
          label: person.name,
          shape: "circularImage",
          image: person.photo_url || fallbackImage,
          size: person.is_external ? 24 : 30,
          x,
          y,
          fixed: { x: true, y: true },
          font: { color: "#e5e7eb", size: 11 },
          color: { border: borderColor, background: "#111827" },
          borderWidth: 3,
          borderDashes: roleKey === "secretWitness" ? [5, 5] : false
        });

        if (!nodeIdByProfile.has(profileId)) nodeIdByProfile.set(profileId, []);
        nodeIdByProfile.get(profileId).push({ nodeId, actionId: action.id });
      });
    });
  });

  const edgeSet = new Set();
  if (localMeta?._connections?.length) {
    localMeta._connections.forEach((connection) => {
      const fromNodes = nodeIdByProfile.get(connection.fromId) || [];
      const toNodes = nodeIdByProfile.get(connection.toId) || [];
      if (!fromNodes.length || !toNodes.length) return;
      const from = fromNodes.find((n) => n.actionId === connection.actionId) || fromNodes[0];
      const to = toNodes.find((n) => n.actionId === connection.actionId) || toNodes[0];
      const key = [from.nodeId, to.nodeId].join("|");
      if (edgeSet.has(key)) return;
      edgeSet.add(key);
      const isCrossAction = from.actionId !== to.actionId;
      edges.push({
        from: from.nodeId,
        to: to.nodeId,
        arrows: connection.direction === "two-way" ? "to, from" : "to",
        dashes: isCrossAction,
        color: { color: `rgba(148, 163, 184, ${isCrossAction ? 0.3 : 0.45})` },
        smooth: { type: "continuous" }
      });
    });
  } else {
    caseData.people.forEach((person) => {
      (person.related_profiles || []).forEach((targetId) => {
        const fromNodes = nodeIdByProfile.get(person.id) || [];
        const toNodes = nodeIdByProfile.get(targetId) || [];
        if (!fromNodes.length || !toNodes.length) return;
        const from = fromNodes[0];
        const to = toNodes[0];
        const key = [from.nodeId, to.nodeId].join("|");
        if (edgeSet.has(key)) return;
        edgeSet.add(key);
        edges.push({
          from: from.nodeId,
          to: to.nodeId,
          arrows: "to",
          color: { color: "rgba(148, 163, 184, 0.35)" },
          smooth: { type: "continuous" }
        });
      });
    });
  }

  nodesCache = nodes;
  edgesCache = edges;
  return { nodes, edges };
}

function filterGraph() {
  const query = nameSearch.value.toLowerCase().trim();
  const tck = tckFilter.value;

  const nodes = nodesCache.filter((node) => {
    if (!node.id.startsWith("p:")) return true;
    const matchesName = !query || node.label.toLowerCase().includes(query);
    const matchesTck = tck === "all" || node.id.includes(`:${tck}:`);
    return matchesName && matchesTck;
  });

  const nodeIds = new Set(nodes.map((n) => n.id));
  const edges = edgesCache.filter((edge) => nodeIds.has(edge.from) && nodeIds.has(edge.to));

  if (network) {
    network.setData({ nodes, edges });
  }
}

function openPersonModal(person) {
  const tabs = document.querySelectorAll(".tab");
  const panels = document.querySelectorAll(".tab-panel");
  tabs.forEach((tab) => tab.classList.remove("active"));
  panels.forEach((panel) => panel.classList.remove("active"));
  if (tabs[0]) tabs[0].classList.add("active");
  if (panels[0]) panels[0].classList.add("active");

  personName.textContent = person.name;
  personRole.textContent = person.role || "";
  personPhoto.src = person.photo_url || fallbackImage;
  const accusationText = (person.tck_articles || []).map((code) => `TCK ${code}`).join(" · ");
  personAccusationsTag.textContent = accusationText || "";

  personAccusationList.innerHTML = "";
  if (!(person.accusations || []).length) {
    const li = document.createElement("li");
    li.textContent = "Suçlama bilgisi yok.";
    personAccusationList.appendChild(li);
  } else {
    (person.accusations || []).forEach((item) => {
      const li = document.createElement("li");
      li.textContent = item;
      personAccusationList.appendChild(li);
    });
  }

  personEvidenceList.innerHTML = "";
  if (!(person.evidence_items || []).length) {
    const li = document.createElement("li");
    li.textContent = "Delil bilgisi yok.";
    personEvidenceList.appendChild(li);
  } else {
    (person.evidence_items || []).forEach((item) => {
      const li = document.createElement("li");
      const ref = item.reference ? ` (${item.reference})` : "";
      li.textContent = `${item.description}${ref}`;
      personEvidenceList.appendChild(li);
    });
  }

  personDefenseList.innerHTML = "";
  if (!(person.defense || []).length) {
    const li = document.createElement("li");
    li.textContent = "Savunma bilgisi yok.";
    personDefenseList.appendChild(li);
  } else {
    (person.defense || []).forEach((item) => {
      const li = document.createElement("li");
      li.textContent = item;
      personDefenseList.appendChild(li);
    });
  }

  personRelatedList.innerHTML = "";
  const related = person.related_profiles || [];
  if (!related.length) {
    const li = document.createElement("li");
    li.textContent = "İlişkili kişi yok.";
    personRelatedList.appendChild(li);
  } else {
    related.forEach((id) => {
      const target = people.find((p) => p.id === id);
      if (!target) return;
      const li = document.createElement("li");
      const btn = document.createElement("button");
      btn.type = "button";
      btn.textContent = target.name;
      btn.addEventListener("click", () => openPersonModal(target));
      li.appendChild(btn);
      personRelatedList.appendChild(li);
    });
  }

  personModal.showModal();
}

function setupTabs() {
  const tabs = document.querySelectorAll(".tab");
  const panels = document.querySelectorAll(".tab-panel");

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("active"));
      panels.forEach((p) => p.classList.remove("active"));
      tab.classList.add("active");
      const panel = document.querySelector(`.tab-panel[data-panel="${tab.dataset.tab}"]`);
      if (panel) panel.classList.add("active");
    });
  });
}

async function loadCase(caseId) {
  const caseData = await fetchJSON(`/api/cases/${caseId}`);
  people = caseData.people || [];

  renderCaseInfo(caseData);
  setTckOptions(caseData.tck_articles || []);

  const graph = buildGraph(caseData);

  const options = {
    interaction: { dragView: true, zoomView: true },
    physics: false,
    edges: {
      smooth: { type: "continuous" },
      color: { color: "rgba(148, 163, 184, 0.35)" }
    },
    nodes: {
      borderWidth: 2,
      shape: "circularImage",
      font: { face: "Inter" }
    }
  };

  const container = document.getElementById("network");

  if (!network) {
    network = new vis.Network(container, { nodes: graph.nodes, edges: graph.edges }, options);
    network.on("selectNode", (params) => {
      const nodeId = params.nodes[0];
      if (!nodeId.startsWith("p:")) return;
      const baseId = nodeId.split(":").pop();
      const person = people.find((p) => p.id === baseId);
      if (person) openPersonModal(person);
    });
    network.on("hoverNode", (params) => {
      const active = params.node;
      const edges = edgesCache.map((edge) => ({
        ...edge,
        color:
          edge.from === active || edge.to === active
            ? { color: "rgba(226, 232, 240, 0.75)" }
            : { color: "rgba(148, 163, 184, 0.2)" }
      }));
      network.setData({ nodes: nodesCache, edges });
    });
    network.on("blurNode", () => {
      network.setData({ nodes: nodesCache, edges: edgesCache });
    });
  } else {
    network.setData({ nodes: graph.nodes, edges: graph.edges });
  }

  filterGraph();
}

function loadLocalData() {
  const raw = localStorage.getItem("dcc_data");
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (err) {
    return null;
  }
}

function buildCaseFromLocal(local, caseId) {
  const caseItem = local.cases.find((c) => c.id === caseId);
  if (!caseItem) return null;
  const profiles = local.profiles.filter((p) => p.caseId === caseId);
  const actions = local.actions.filter((a) => a.caseId === caseId);
  const connections = local.connections.filter((c) => c.caseId === caseId);

  const tckArticles = actions
    .flatMap((a) => a.tckCodes || [])
    .filter(Boolean)
    .map((code) => ({ code, title: "" }))
    .filter((v, i, arr) => arr.findIndex((x) => x.code === v.code) === i);

  const peopleData = profiles.map((p) => ({
    id: p.id,
    name: p.name,
    role: p.role,
    photo_url: p.photo,
    tck_articles: p.tckCodes || [],
    accusations: p.accusations ? p.accusations.split("\n").filter(Boolean) : [],
    evidence_items: p.evidence ? p.evidence.split("\n").map((d) => ({ description: d })) : [],
    defense: p.defense ? p.defense.split("\n").filter(Boolean) : [],
    related_profiles: [],
    is_external: false
  }));

  return {
    id: caseItem.id,
    title: caseItem.title,
    case_number: caseItem.caseNumber,
    court_name: caseItem.courtName,
    prosecutor: caseItem.prosecutor,
    judge: caseItem.judge,
    court_panel: (caseItem.panel || []).join(" · "),
    date: caseItem.date,
    status: caseItem.status,
    hearing_count: "",
    start_date: caseItem.date,
    last_hearing_date: "",
    summary: "",
    tck_articles: tckArticles,
    people: peopleData,
    _actions: actions,
    _connections: connections
  };
}

async function loadData() {
  const local = loadLocalData();
  if (local && local.cases.length) {
    cases = local.cases.map((c) => ({ id: c.id, title: c.title }));
    setCaseOptions();
    const params = new URLSearchParams(window.location.search);
    const caseId = params.get("caseId") || local.cases[0].id;
    if (caseId) {
      caseSelect.value = caseId;
      const built = buildCaseFromLocal(local, caseId);
      if (built) {
        people = built.people || [];
        renderCaseInfo(built);
        setTckOptions(built.tck_articles || []);
        const graph = buildGraph(built, built);
        const options = {
          interaction: { dragView: true, zoomView: true },
          physics: false,
          edges: { smooth: { type: "continuous" }, color: { color: "rgba(148, 163, 184, 0.35)" } },
          nodes: { borderWidth: 2, shape: "circularImage", font: { face: "Inter" } }
        };
        const container = document.getElementById("network");
        if (!network) {
          network = new vis.Network(container, { nodes: graph.nodes, edges: graph.edges }, options);
          network.on("selectNode", (params) => {
            const nodeId = params.nodes[0];
            if (!nodeId.startsWith("p:")) return;
            const baseId = nodeId.split(":").pop();
            const person = people.find((p) => p.id === baseId);
            if (person) openPersonModal(person);
          });
        } else {
          network.setData({ nodes: graph.nodes, edges: graph.edges });
        }
        filterGraph();
      }
    }
    return;
  }

  cases = await fetchJSON("/api/cases");
  setCaseOptions();
  const params = new URLSearchParams(window.location.search);
  const caseId = params.get("caseId") || (cases[0] ? cases[0].id : null);
  if (caseId) {
    caseSelect.value = caseId;
    await loadCase(caseId);
  }
}

caseSelect.addEventListener("change", (event) => loadCase(event.target.value));
nameSearch.addEventListener("input", filterGraph);
tckFilter.addEventListener("change", filterGraph);
caseDetailBtn.addEventListener("click", () => caseModal.showModal());
caseClose.addEventListener("click", () => caseModal.close());
personClose.addEventListener("click", () => personModal.close());

mapClose.addEventListener("click", () => {
  window.location.href = "/";
});

window.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    if (personModal.open) return personModal.close();
    if (caseModal.open) return caseModal.close();
    window.location.href = "/";
  }
});

setupTabs();
loadData();

const caseGrid = document.getElementById("case-grid");
const caseSearch = document.getElementById("case-search");
const statCases = document.getElementById("stat-cases");
const statDefendants = document.getElementById("stat-defendants");
const previewMap = document.getElementById("preview-map");
const openFull = document.getElementById("open-full");

let cases = [];
let previewNetwork = null;
let selectedCaseId = null;

async function fetchJSON(url, options) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "İstek başarısız");
  return data;
}

function renderCaseGrid() {
  const query = caseSearch.value.toLowerCase().trim();
  caseGrid.innerHTML = "";

  const filtered = cases.filter((item) => {
    if (!query) return true;
    return (
      item.title.toLowerCase().includes(query) ||
      (item.case_number || "").toLowerCase().includes(query) ||
      (item.court_name || "").toLowerCase().includes(query)
    );
  }).slice(0, 6);

  if (!filtered.length) {
    caseGrid.innerHTML = `<div class="muted">Kayıt bulunamadı.</div>`;
    return;
  }

  for (const item of filtered) {
    const card = document.createElement("div");
    card.className = "case-card";
    card.innerHTML = `
      <span class="badge">${item.status || "Devam ediyor"}</span>
      <h4>${item.title || "Beşiktaş Davası"}</h4>
      <p class="muted">Esas No: <span class="mono">${item.case_number || "2024/142"}</span></p>
      <p class="muted">Mahkeme: ${item.court_name || "İstanbul 14. Ağır Ceza"}</p>
      <p class="muted">Savcı: ${item.prosecutor || "[İsim]"}</p>
      <p class="muted">Heyet: ${item.court_panel || "[Başkan + Üyeler]"}</p>
      <p class="muted">Tarih: ${item.date || "15.01.2024"}</p>
      <p class="muted">Sanık: ${item.defendantCount || 0}</p>
      <button class="btn primary small">Haritaya geç</button>
    `;
    card.addEventListener("click", () => {
      selectCase(item.id);
    });
    caseGrid.appendChild(card);
  }
}

function updateStats() {
  if (statCases) statCases.textContent = cases.length;
  if (statDefendants) {
    const total = cases.reduce((sum, item) => sum + (item.defendantCount || 0), 0);
    statDefendants.textContent = total;
  }
}

async function buildPreview(caseId) {
  if (!caseId) return;
  const data = await fetchJSON(`/api/cases/${caseId}`);
  if (openFull) openFull.href = `/map.html?caseId=${caseId}`;
  const previewLink = document.querySelector(".preview-wrap");
  if (previewLink) previewLink.href = `/map.html?caseId=${caseId}`;

  const nodes = (data.people || []).map((p) => ({
    id: p.id,
    label: p.name,
    shape: "circularImage",
    image: p.photo_url || "/assets/default-avatar.svg",
    size: 20,
    font: { color: "#e5e7eb", size: 10, face: "Inter" },
    color: { border: "#9ca3af", background: "#111827" }
  }));

  const edges = [];
  const edgeSet = new Set();
  for (const person of data.people || []) {
    for (const target of person.related_profiles || []) {
      const key = [person.id, target].sort().join("|");
      if (edgeSet.has(key)) continue;
      edgeSet.add(key);
      edges.push({ from: person.id, to: target, color: { color: "rgba(148,163,184,0.35)" } });
    }
  }

  const options = {
    interaction: { dragView: true, zoomView: true },
    physics: { stabilization: false },
    edges: { smooth: { type: "continuous" } }
  };

  if (!previewNetwork) {
    previewNetwork = new vis.Network(previewMap, { nodes, edges }, options);
  } else {
    previewNetwork.setData({ nodes, edges });
  }
}

async function selectCase(caseId) {
  selectedCaseId = caseId;
  await buildPreview(caseId);
}

async function loadData() {
  cases = await fetchJSON("/api/cases");
  renderCaseGrid();
  updateStats();
  if (cases[0]) {
    await selectCase(cases[0].id);
  }
}

caseSearch.addEventListener("input", renderCaseGrid);

loadData();

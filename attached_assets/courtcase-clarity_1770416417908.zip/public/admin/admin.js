const LOGIN_USER = "admin";
const LOGIN_PASS = "Couragea1!";
const STORAGE_KEY = "dcc_data";

const loginScreen = document.getElementById("login-screen");
const loginForm = document.getElementById("login-form");
const loginError = document.getElementById("login-error");
const logoutBtn = document.getElementById("logout");

const menuItems = document.querySelectorAll(".menu-item");
const sections = document.querySelectorAll("[data-section]");

const caseForm = document.getElementById("case-form");
const caseList = document.getElementById("case-list");

const actionForm = document.getElementById("action-form");
const actionList = document.getElementById("action-list");
const actionCaseSelect = document.getElementById("action-case");

const profileForm = document.getElementById("profile-form");
const profileList = document.getElementById("profile-list");
const profileCaseSelect = document.getElementById("profile-case");
const profileActionsSelect = document.getElementById("profile-actions");
const profileTckSelect = document.getElementById("profile-tcks");

const connectionForm = document.getElementById("connection-form");
const connectionList = document.getElementById("connection-list");
const connectionCaseSelect = document.getElementById("connection-case");
const connectionFromSelect = document.getElementById("connection-from");
const connectionToSelect = document.getElementById("connection-to");
const connectionActionSelect = document.getElementById("connection-action");

const exportBtn = document.getElementById("export-json");
const importInput = document.getElementById("import-json");

function loadData() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    const seed = { cases: [], actions: [], profiles: [], connections: [] };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(seed));
    return seed;
  }
  try {
    return JSON.parse(raw);
  } catch (err) {
    return { cases: [], actions: [], profiles: [], connections: [] };
  }
}

function saveData(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function setSection(tab) {
  menuItems.forEach((btn) => btn.classList.toggle("active", btn.dataset.tab === tab));
  sections.forEach((section) => {
    section.hidden = section.dataset.section !== tab;
  });
}

function fillSelect(select, items, labelKey = "title") {
  select.innerHTML = "";
  items.forEach((item) => {
    const option = document.createElement("option");
    option.value = item.id;
    option.textContent = item[labelKey];
    select.appendChild(option);
  });
}

function fillMulti(select, items, labelKey = "title") {
  select.innerHTML = "";
  items.forEach((item) => {
    const option = document.createElement("option");
    option.value = item.id;
    option.textContent = item[labelKey];
    select.appendChild(option);
  });
}

function renderLists(data) {
  caseList.innerHTML = "";
  data.cases.forEach((c) => {
    const div = document.createElement("div");
    div.className = "list-item";
    div.innerHTML = `<strong>${c.title}</strong><br /><span class="muted">${c.caseNumber}</span>`;
    caseList.appendChild(div);
  });

  actionList.innerHTML = "";
  data.actions.forEach((a) => {
    const div = document.createElement("div");
    div.className = "list-item";
    div.innerHTML = `<strong>${a.title}</strong><br /><span class="muted">${a.tckCodes.join(", ")}</span>`;
    actionList.appendChild(div);
  });

  profileList.innerHTML = "";
  data.profiles.forEach((p) => {
    const div = document.createElement("div");
    div.className = "list-item";
    div.innerHTML = `<strong>${p.name}</strong><br /><span class="muted">${p.role}</span>`;
    profileList.appendChild(div);
  });

  connectionList.innerHTML = "";
  data.connections.forEach((c) => {
    const div = document.createElement("div");
    div.className = "list-item";
    div.innerHTML = `<strong>${c.fromId} → ${c.toId}</strong><br /><span class="muted">${c.direction}</span>`;
    connectionList.appendChild(div);
  });
}

function refreshSelectors(data) {
  fillSelect(actionCaseSelect, data.cases, "title");
  fillSelect(profileCaseSelect, data.cases, "title");
  fillSelect(connectionCaseSelect, data.cases, "title");

  const selectedCaseId = profileCaseSelect.value || (data.cases[0] && data.cases[0].id);
  const actionsForCase = data.actions.filter((a) => a.caseId === selectedCaseId);
  const profilesForCase = data.profiles.filter((p) => p.caseId === selectedCaseId);

  fillMulti(profileActionsSelect, actionsForCase, "title");
  const tckOptions = actionsForCase
    .flatMap((a) => a.tckCodes)
    .filter(Boolean)
    .map((code) => ({ id: code, title: code }))
    .filter((v, i, arr) => arr.findIndex((x) => x.id === v.id) === i);
  fillMulti(profileTckSelect, tckOptions, "title");

  fillSelect(connectionActionSelect, actionsForCase, "title");
  fillSelect(connectionFromSelect, profilesForCase, "name");
  fillSelect(connectionToSelect, profilesForCase, "name");
}

function sync() {
  const data = loadData();
  renderLists(data);
  refreshSelectors(data);
}

loginForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const formData = new FormData(loginForm);
  const username = formData.get("username");
  const password = formData.get("password");
  if (username === LOGIN_USER && password === LOGIN_PASS) {
    localStorage.setItem("dcc_admin_authed", "1");
    loginScreen.style.display = "none";
  } else {
    loginError.textContent = "Hatalı kullanıcı adı veya şifre.";
  }
});

logoutBtn.addEventListener("click", () => {
  localStorage.removeItem("dcc_admin_authed");
  loginScreen.style.display = "grid";
});

menuItems.forEach((btn) => {
  btn.addEventListener("click", () => setSection(btn.dataset.tab));
});

caseForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = loadData();
  const formData = new FormData(caseForm);
  const id = `case_${Date.now()}`;
  const panel = formData.get("panel")
    ? formData.get("panel").split(",").map((v) => v.trim()).filter(Boolean)
    : [];
  data.cases.push({
    id,
    title: formData.get("title"),
    caseNumber: formData.get("caseNumber"),
    courtName: formData.get("courtName"),
    prosecutor: formData.get("prosecutor"),
    judge: formData.get("judge"),
    panel,
    date: formData.get("date"),
    status: formData.get("status")
  });
  saveData(data);
  caseForm.reset();
  sync();
});

actionForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = loadData();
  const formData = new FormData(actionForm);
  const id = `action_${Date.now()}`;
  const tckCodes = formData.get("tckCodes")
    ? formData.get("tckCodes").split(",").map((v) => v.trim()).filter(Boolean)
    : [];
  data.actions.push({
    id,
    caseId: formData.get("caseId"),
    title: formData.get("title"),
    description: formData.get("description"),
    date: formData.get("date"),
    tckCodes
  });
  saveData(data);
  actionForm.reset();
  sync();
});

profileCaseSelect.addEventListener("change", sync);
connectionCaseSelect.addEventListener("change", sync);

profileForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = loadData();
  const formData = new FormData(profileForm);
  const id = `profile_${Date.now()}`;
  const actionIds = Array.from(profileActionsSelect.selectedOptions).map((o) => o.value);
  const tckCodes = Array.from(profileTckSelect.selectedOptions).map((o) => o.value);
  data.profiles.push({
    id,
    caseId: formData.get("caseId"),
    name: formData.get("name"),
    photo: formData.get("photo"),
    role: formData.get("role"),
    actionIds,
    tckCodes,
    accusations: formData.get("accusations"),
    evidence: formData.get("evidence"),
    defense: formData.get("defense")
  });
  saveData(data);
  profileForm.reset();
  sync();
});

connectionForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = loadData();
  const formData = new FormData(connectionForm);
  const id = `connection_${Date.now()}`;
  data.connections.push({
    id,
    caseId: formData.get("caseId"),
    fromId: formData.get("fromId"),
    toId: formData.get("toId"),
    actionId: formData.get("actionId"),
    direction: formData.get("direction")
  });
  saveData(data);
  connectionForm.reset();
  sync();
});

exportBtn.addEventListener("click", () => {
  const data = loadData();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "dava-analiz.json";
  link.click();
  URL.revokeObjectURL(url);
});

importInput.addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  const text = await file.text();
  try {
    const parsed = JSON.parse(text);
    saveData(parsed);
    sync();
  } catch (err) {
    alert("JSON okunamadı.");
  }
});

function initAuth() {
  const authed = localStorage.getItem("dcc_admin_authed") === "1";
  loginScreen.style.display = authed ? "none" : "grid";
}

initAuth();
sync();

const caseGrid = document.getElementById("case-grid");
const caseSearch = document.getElementById("case-search");
const statCases = document.getElementById("stat-cases");
const statProsecutor = document.getElementById("stat-prosecutor");
const statPanel = document.getElementById("stat-panel");
const previewMap = document.getElementById("preview-map");
const openFull = document.getElementById("open-full");

let cases = [];
let previewNetwork = null;
let selectedCaseId = null;

async function fetchJSON(url, options) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "İstek başarısız");
  return data;
}

function renderCaseGrid() {
  const query = caseSearch.value.toLowerCase().trim();
  caseGrid.innerHTML = "";

  const filtered = cases.filter((item) => {
    if (!query) return true;
    return (
      item.title.toLowerCase().includes(query) ||
      (item.case_number || "").toLowerCase().includes(query) ||
      (item.court_name || "").toLowerCase().includes(query)
    );
  });

  if (!filtered.length) {
    caseGrid.innerHTML = `<div class="muted">Kayıt bulunamadı.</div>`;
    return;
  }

  for (const item of filtered) {
    const card = document.createElement("div");
    card.className = "case-card";
    card.innerHTML = `
      <div class="case-folder-icon">📂</div>
      <h4>${item.title}</h4>
      <p class="muted">${item.summary || ""}</p>
      <div class="case-meta">
        <span>${item.date || ""}</span> • <span>${item.status || ""}</span>
      </div>
    `;
    card.addEventListener("click", () => {
      selectCase(item.id);
    });
    caseGrid.appendChild(card);
  }
}

function updateStats(caseData) {
  if (statCases) statCases.textContent = cases.length;
  if (statProsecutor) statProsecutor.textContent = caseData?.prosecutor || "—";
  if (statPanel) statPanel.textContent = caseData?.court_panel || "—";
}

async function buildPreview(caseId) {
  if (!caseId) return;
  const data = await fetchJSON(`/api/cases/${caseId}`);
  updateStats(data);
  if (openFull) openFull.href = `/map.html?caseId=${caseId}`;

  const nodes = (data.people || []).map((p) => ({
    id: p.id,
    label: p.name,
    shape: "circularImage",
    image: p.photo_url || "/assets/default-avatar.svg",
    size: 20,
    font: { color: "#e5e7eb", size: 10, face: "Inter" },
    color: { border: "#9ca3af", background: "#111827" }
  }));

  const edges = [];
  const edgeSet = new Set();
  for (const person of data.people || []) {
    for (const target of person.related_profiles || []) {
      const key = [person.id, target].sort().join("|");
      if (edgeSet.has(key)) continue;
      edgeSet.add(key);
      edges.push({ from: person.id, to: target, color: { color: "rgba(148,163,184,0.35)" } });
    }
  }

  const options = {
    interaction: { dragView: true, zoomView: true },
    physics: { stabilization: false },
    edges: { smooth: { type: "continuous" } }
  };

  if (!previewNetwork) {
    previewNetwork = new vis.Network(previewMap, { nodes, edges }, options);
  } else {
    previewNetwork.setData({ nodes, edges });
  }
}

async function selectCase(caseId) {
  selectedCaseId = caseId;
  await buildPreview(caseId);
}

async function loadData() {
  cases = await fetchJSON("/api/cases");
  renderCaseGrid();
  if (cases[0]) {
    await selectCase(cases[0].id);
  } else {
    updateStats(null);
  }
}

caseSearch.addEventListener("input", renderCaseGrid);

loadData();
